import streamlit as st
import pandas as pd
from analyzer import analyze

st.set_page_config(page_title="TikTok Produtos", page_icon="🛒", layout="centered")

st.title("🛒 TikTok Produtos")
st.write("Descubra se um produto parece apenas viral ou se apresenta sinais de potencial de venda.")

tab1, tab2 = st.tabs(["📋 Colar dados", "📁 Enviar CSV"])

with tab1:
    st.subheader("Teste rápido")
    produto = st.text_input("Nome do produto", "Produto teste")
    views = st.number_input("Visualizações", min_value=0, value=100000)
    likes = st.number_input("Curtidas", min_value=0, value=10000)
    comments = st.number_input("Comentários", min_value=0, value=1000)
    shares = st.number_input("Compartilhamentos", min_value=0, value=2000)
    texto = st.text_area(
        "Texto/descrição do vídeo",
        "Onde compra? Manda o link! Quero comprar."
    )

    if st.button("🔎 Analisar produto", use_container_width=True):
        df = pd.DataFrame([{
            "id": "manual",
            "video_description": f"{produto} — {texto}",
            "create_time": pd.Timestamp.now(tz="UTC").isoformat(),
            "region_code": "BR",
            "view_count": views,
            "like_count": likes,
            "comment_count": comments,
            "share_count": shares
        }])
        result = analyze(df).iloc[0]

        score = result["opportunity_score"]
        if score >= 80:
            status = "🟢 Alto sinal para investigar"
        elif score >= 60:
            status = "🟡 Sinal interessante"
        elif score >= 40:
            status = "🟠 Precisa de mais validação"
        else:
            status = "🔴 Sinal fraco"

        st.metric("Score de oportunidade", f"{score}/100")
        st.subheader(status)

        c1, c2, c3 = st.columns(3)
        c1.metric("Views", f"{int(views):,}".replace(",", "."))
        c2.metric("Comentários", f"{int(comments):,}".replace(",", "."))
        c3.metric("Compartilhamentos", f"{int(shares):,}".replace(",", "."))

        st.info(
            "O score é uma triagem. Ele não garante vendas. "
            "Antes de investir, confirme preço, margem, concorrência, "
            "qualidade, frete e demanda."
        )

with tab2:
    st.subheader("Analisar vários vídeos")
    uploaded = st.file_uploader(
        "Envie um arquivo CSV", type=["csv"]
    )

    if uploaded:
        try:
            df = pd.read_csv(uploaded)
            result = analyze(df)
            st.dataframe(result, use_container_width=True)

            csv = result.to_csv(index=False).encode("utf-8-sig")
            st.download_button(
                "⬇️ Baixar análise",
                csv,
                "analise_produtos_tiktok.csv",
                "text/csv",
                use_container_width=True
            )
        except Exception as e:
            st.error(f"Não consegui ler o CSV: {e}")

st.divider()
st.caption("Versão para celular — análise de sinais, não garantia de vendas.")
