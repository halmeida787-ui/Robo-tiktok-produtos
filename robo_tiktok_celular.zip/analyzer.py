import math
import pandas as pd

BUY_WORDS = [
    "onde compra", "onde comprar", "link", "preço", "quanto custa",
    "comprar", "comprei", "chegou", "pedido", "frete", "cupom",
    "tem link", "manda o link", "quero um", "quero comprar"
]

def num(x):
    try:
        return float(x or 0)
    except:
        return 0.0

def age_days(value):
    try:
        dt = pd.to_datetime(value, utc=True)
        now = pd.Timestamp.now(tz="UTC")
        return max((now-dt).total_seconds()/86400, .25)
    except:
        return 7

def intent(text):
    text = str(text or "").lower()
    return min(sum(w in text for w in BUY_WORDS)/3, 1)

def analyze(df):
    df = df.copy()

    defaults = {
        "view_count": 0, "like_count": 0, "comment_count": 0,
        "share_count": 0, "video_description": "",
        "create_time": pd.Timestamp.now(tz="UTC").isoformat()
    }
    for col, value in defaults.items():
        if col not in df.columns:
            df[col] = value

    scores = []
    for _, row in df.iterrows():
        views = max(num(row["view_count"]), 1)
        likes = num(row["like_count"])
        comments = num(row["comment_count"])
        shares = num(row["share_count"])

        age = age_days(row["create_time"])
        velocity = min(math.log10(views+1)/max(age,1)/2, 1)

        engagement = min(
            (likes/views)*.25 +
            (comments/views)*8 +
            (shares/views)*4, 1
        )

        buy = intent(row["video_description"])
        share_signal = min(shares/max(views*.02,1), 1)

        score = (
            velocity*25 +
            engagement*20 +
            buy*25 +
            min(math.log10(views+1)/7,1)*15 +
            share_signal*15
        )
        scores.append(round(min(score,100),1))

    df["opportunity_score"] = scores

    df["classificacao"] = df["opportunity_score"].apply(
        lambda x:
        "🟢 Investigar com prioridade" if x >= 80 else
        "🟡 Investigar" if x >= 60 else
        "🟠 Observar" if x >= 40 else
        "🔴 Sinal fraco"
    )

    return df.sort_values("opportunity_score", ascending=False)
