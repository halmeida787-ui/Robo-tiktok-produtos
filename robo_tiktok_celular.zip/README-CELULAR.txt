COMO USAR NO CELULAR

Esta versão foi feita para ser aberta como aplicativo web pelo navegador.

IMPORTANTE:
O ZIP não vira automaticamente um aplicativo Android. Para colocar esta
versão online, você precisa publicar os arquivos em um serviço que execute
Python/Streamlit. Depois disso, basta abrir o endereço pelo Chrome no celular.

A tela possui:
1. Teste manual: coloque produto, views, curtidas, comentários e compartilhamentos.
2. CSV: envie vários vídeos e receba a classificação.
3. Download: baixe a análise em CSV.

O score é apenas uma ferramenta de triagem e não garante vendas.
